public class TestProgram
{
   public static void main(String args[])
   {
     Person p=new Person("phaneendra","vijayawada");
     System.out.println("Name....="+p.getName());
     System.out.println("Addres....="+p.getAddress());
     System.out.println(p);
     
     Student s=new Student("ram","velvadam","MCA",1,45500);
     System.out.println(s);
     
     Staff st=new Staff("Rajendra kumar","Professor Department of MCA","Lakireddy Balireddy College of Engineering",55000);
     System.out.println(st);
   }
} 