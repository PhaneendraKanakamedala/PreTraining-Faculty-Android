public class TestProgram 
{
   public static void main(String args[])
   {
      Circle cir1=new Circle();
      Circle cir2=new Circle(15);
      System.out.println("First Circle....\n"+cir1);
      System.out.println("Second Circle...\n"+cir2);

      Rectangle rec1=new Rectangle();
      Rectangle rec2=new Rectangle(4,9);
      Rectangle rec3=new Rectangle(5,7,"orange",true);
      System.out.println("First Rectangle....\n"+rec1);
      System.out.println("Second Rectangle...\n"+rec2);
      System.out.println("Third Rectangle...\n"+rec3);
     
     
      Square sq1=new Square();
      Square sq2=new Square(20);
      System.out.println("First Square....\n"+sq1);
      System.out.println("Second Square...\n"+sq2);
   }
  
}